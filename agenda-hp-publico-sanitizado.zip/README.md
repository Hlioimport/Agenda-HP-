# Agenda HP — Hélio Pedro

Projeto multiplataforma personalizado a partir do `index.html` enviado. O nome do aplicativo é **Agenda HP**, com o monograma HP, identidade visual de calendário em azul-marinho e turquesa e splash screen com “HÉLIO PEDRO”. A interface original já traz referências internas à Agenda HP; não alterei regras nem dados da aplicação.

## Plataformas

- Android e iOS: aplicativo híbrido instalado, empacotado com Capacitor.
- Windows: instalador `.exe` por Electron.
- PWA: opção instalável em navegadores compatíveis.

## Requisitos

- Node.js LTS e npm.
- Android: Android Studio + Android SDK.
- iOS: macOS com Xcode; certificados/perfil e conta Apple Developer para distribuição.
- Windows: Windows para compilar e testar o instalador Electron.

## Gerar os assets nativos personalizados

O arquivo `assets/icon.png` (1024×1024) e `assets/splash.png` (2732×2732) são as fontes usadas para gerar ícones e telas de abertura nas plataformas. Na pasta do projeto, rode:

```sh
npm install
npm run assets:generate
```

Em seguida, adicione as plataformas e sincronize os arquivos web e o plugin de splash:

```sh
npx cap add android
npx cap add ios
npx cap sync
```

Se uma pasta `android/` ou `ios/` já existir, não rode `cap add` novamente; use `npx cap sync`. Abra no Android Studio/Xcode com `npm run android` ou `npm run ios`, compile e assine usando seus certificados. O splash nativo depende da geração dos recursos e do plugin `@capacitor/splash-screen`, já configurados no projeto.

## Windows

```sh
npm install
npm run desktop:win
```

O instalador é gerado em `release/`. Para desenvolvimento: `npm run desktop:dev`.

## PWA / teste web

```sh
npm install
npm run web:serve
```

Para instalação PWA em aparelhos reais, hospede em HTTPS.

## Validações antes da publicação

1. Teste login e retorno OAuth do Firebase/Google em cada sistema. O HTML fornecido já inclui Firebase e usa autenticação; dentro de WebViews nativas, login em pop-up/retorno pode exigir configuração adicional dos domínios e provedores autorizados no Firebase/Google.
2. Teste alarmes, permissões e notificações em cada aparelho. Uma interface web empacotada não garante execução de alarmes em segundo plano, sobretudo no iOS.
3. Personalize política de privacidade, descrição de loja, capturas de tela e assinatura dos instaladores antes de publicar.

A configuração cliente do Firebase que já estava embutida no HTML foi preservada. Não alterei regras nem credenciais do projeto Firebase. O código cliente não substitui regras de segurança corretas no Firebase.


## Gerar o APK pelo Xiaomi usando GitHub Actions (sem computador)

A workflow pronta está em `cloud-build/build-android.yml`. O GitHub precisa dessa configuração em `.github/workflows/build-android.yml` na raiz de um repositório; o APK de teste sai como um artefato para baixar. Instruções detalhadas para fazer isso pelo navegador do celular serão fornecidas separadamente. Mantenha o repositório privado.


## Dados pré-cadastrados na cópia pública

Na cópia preparada para publicação, os campos `name` e `phone` dos três registros iniciais de mensalistas foram deixados vazios. As demais configurações e campos do app foram mantidos conforme solicitado; portanto e-mails, descrições e valores continuam presentes no HTML. Revise esses dados antes de publicar publicamente.
